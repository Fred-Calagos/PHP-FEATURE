<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "root", "exercises");
$output = '';

    if(isset($_POST["query"]))
        {
        $search = mysqli_real_escape_string($connect, $_POST["query"]);
        $query = "
        SELECT * FROM autos 
        WHERE product LIKE '%".$search."%'
        OR supplier LIKE '%".$search."%' 
        ";
        }
    else
    {
    $query = "
    SELECT * FROM autos ORDER BY id
    ";
    }

    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0)
        {
            $output .= '
            <div class="table-responsive">
            <table class="table">
                <tr>
                <th>Supplier</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Unit</th>
                <th>Unit Cost</th>
                <th>Total Cost</th>
                </tr>
            ';
        while($row = mysqli_fetch_array($result))
        {
            $output .= '
            <tr>
                <td>'.$row["supplier"].'</td>
                <td>'.$row["product"].'</td>
                <td>'.$row["quantity"].'</td>
                <td>'.$row["unit"].'</td>
                <td>'.$row["unit_cost"].'</td>
                <td>'.$row["total_cost"].'</td>
            </tr>
            ';
        }
            echo $output;
        }
    else
        {
            echo 'Data Not Found';
        }

    ?>