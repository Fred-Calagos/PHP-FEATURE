<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<!-- jQuery UI library -->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.13.2/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>
    <title>AUTO COMPUTE</title> 
    <!-- KATA TOGONON BSIT 3-A-->
</head>
<body>
    <div class="compute">
        <form action="postenquiry.php" method="post" name="myform">
        <h1>Auto Compute Feature</h1>
            <label>Quantity:</label><br>
            <input type="text" name="qty" />
            <br/>
            <label>Unit Cost:</label><br>
            <input type="text" name="Cost" onkeyup="calculate()" />
            <br/>
            <label>Total Cost:</label><br>
            <input type="text" name="textbox5"/>
        </form>
    </div>
    <script>
        function calculate() {
    if (isNaN(document.forms["myform"]["qty"].value) || document.forms["myform"]["qty"].value == "") {
        var text1 = 0;
    } else {
        var text1 = parseInt(document.forms["myform"]["qty"].value);
    }
    if (isNaN(document.forms["myform"]["Cost"].value) || document.forms["myform"]["Cost"].value == "") {
        var text2 = 0;
    } else {
        var text2 = parseFloat(document.forms["myform"]["Cost"].value);
    }
    document.forms["myform"]["textbox5"].value = (text1 * text2);
}
    </script>
    <style>
        form {
            width: 200px;
            height: min-content;
            padding: 20px;
            border-radius: 12px;
            background-color: teal;
            align-items: center;
            
        }
        form input[type=text]{
            outline: none;
            padding: 12px;
            border-radius: 10px;
        }
        h1{
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 39px;
        }
        label{
            font-size: 20px;
        }
    </style>
</body>
</html>